function callbackFn(details) {
    return {
        authCredentials: {
            username: "KU0G687W",
            password: "25E8DAFEEA04"
        }
    };
}

chrome.webRequest.onAuthRequired.addListener(
    callbackFn,
    {urls: ["<all_urls>"]},
    ['blocking']
);